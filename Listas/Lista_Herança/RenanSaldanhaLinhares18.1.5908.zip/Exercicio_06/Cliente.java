public class Cliente {

  String razaoSocial;
  String CNPJ;
  String endereco;
  String telefone;
  String pessoaDeContato;

  public Cliente(String razaoSocial, String CNPJ, String endereco, String telefone, String pessoaDeContato){
    this.razaoSocial = razaoSocial;
    this.CNPJ = cnpj;
    this.endereco = endereco;
    this.telefone = telefone;
    this.pessoaDeContato = pessoaDeContato;
  }
}
