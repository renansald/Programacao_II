public class Funcionarios{
  String nome;
  String endereco;
  String telefone;
  String RG;
  String CPF;
  String cargo;
  String salario;

  public Funcionarios(String nome, String endereco, String telefone, String RG, String CPF, String cargo){
    this.nome = nome;
    this.endereco = endereco;
    this.telefone = telefone;
    this.RG = RG;
    this.CPF = CPF;
    this.cargo = cargo;
    this.salario = salario;
  }

}
